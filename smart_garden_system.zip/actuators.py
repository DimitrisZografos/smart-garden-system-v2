"""
Smart Garden System - Actuator Module
Created by: Dimitris Zografos
Date: May 2025

This module handles all actuator interactions for the Smart Garden System.
It provides functions to control the water pump and other potential actuators.
"""

import time
import logging
from typing import Dict, Any

# Set up logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('actuators')

# Try to import hardware-specific libraries
try:
    import RPi.GPIO as GPIO
    HARDWARE_AVAILABLE = True
except ImportError:
    logger.warning("RPi.GPIO library not available. Running in simulation mode.")
    HARDWARE_AVAILABLE = False

class ActuatorManager:
    """
    Manages all actuators in the Smart Garden System.
    
    This class provides methods to initialize actuators and control them
    based on sensor readings and system rules.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the actuator manager with the provided configuration.
        
        Args:
            config: Dictionary containing actuator configuration from config.yaml
        """
        self.config = config
        self.hardware_config = config.get('hardware', {})
        self.pump_config = self.hardware_config.get('pump', {})
        self.pump_pin = self.pump_config.get('pin', 18)
        self.pump_duration = self.pump_config.get('duration', 10)  # seconds
        
        # Initialize GPIO if hardware is available
        if HARDWARE_AVAILABLE:
            self._setup_gpio()
        else:
            logger.info("Hardware not available. Actuators will simulate actions.")
    
    def _setup_gpio(self) -> None:
        """Set up GPIO pins for actuators."""
        try:
            # Set up GPIO for pump relay
            GPIO.setmode(GPIO.BCM)
            GPIO.setup(self.pump_pin, GPIO.OUT)
            GPIO.output(self.pump_pin, GPIO.HIGH)  # Start with pump off (relay is active LOW)
            logger.info(f"Water pump relay initialized on pin {self.pump_pin}")
        except Exception as e:
            logger.error(f"Failed to set up GPIO: {str(e)}")
            raise
    
    def activate_pump(self, duration: int = None) -> bool:
        """
        Activate the water pump for the specified duration.
        
        Args:
            duration: Duration in seconds to run the pump. If None, use the configured duration.
            
        Returns:
            True if successful, False otherwise
        """
        if duration is None:
            duration = self.pump_duration
        
        logger.info(f"Activating water pump for {duration} seconds")
        
        if not HARDWARE_AVAILABLE:
            # Simulate pump activation
            logger.info("SIMULATION: Pump activated")
            time.sleep(duration)
            logger.info("SIMULATION: Pump deactivated")
            return True
        
        try:
            # Activate pump (LOW turns on the relay)
            GPIO.output(self.pump_pin, GPIO.LOW)
            
            # Wait for the specified duration
            time.sleep(duration)
            
            # Deactivate pump (HIGH turns off the relay)
            GPIO.output(self.pump_pin, GPIO.HIGH)
            
            logger.info(f"Water pump activated for {duration} seconds")
            return True
        except Exception as e:
            logger.error(f"Error activating water pump: {str(e)}")
            # Try to turn off the pump in case of error
            try:
                GPIO.output(self.pump_pin, GPIO.HIGH)
            except:
                pass
            return False
    
    def water_plants(self, soil_moisture: int) -> bool:
        """
        Water the plants if the soil moisture is below the threshold.
        
        Args:
            soil_moisture: Current soil moisture percentage
            
        Returns:
            True if watering was performed, False otherwise
        """
        # Get threshold from configuration
        threshold = self.hardware_config.get('soil_moisture', {}).get('threshold', 30)
        
        # Check if watering is needed
        if soil_moisture < threshold:
            logger.info(f"Soil moisture ({soil_moisture}%) below threshold ({threshold}%). Watering plants.")
            return self.activate_pump()
        else:
            logger.info(f"Soil moisture ({soil_moisture}%) above threshold ({threshold}%). No watering needed.")
            return False
    
    def cleanup(self) -> None:
        """Clean up resources when shutting down."""
        if HARDWARE_AVAILABLE:
            # Make sure pump is off
            try:
                GPIO.output(self.pump_pin, GPIO.HIGH)
            except:
                pass
            
            # Clean up GPIO
            GPIO.cleanup()
            
            logger.info("Actuator resources cleaned up")


# Example usage if this file is run directly
if __name__ == "__main__":
    import yaml
    
    # Load configuration
    try:
        with open("config/config.yaml", "r") as f:
            config = yaml.safe_load(f)
    except Exception as e:
        print(f"Error loading configuration: {str(e)}")
        config = {}
    
    # Create actuator manager
    actuator_manager = ActuatorManager(config)
    
    # Test pump activation
    print("Testing water pump (5 seconds)...")
    actuator_manager.activate_pump(5)
    
    # Test watering logic
    test_moisture_levels = [10, 20, 30, 40, 50]
    for moisture in test_moisture_levels:
        print(f"\nTesting with soil moisture: {moisture}%")
        watered = actuator_manager.water_plants(moisture)
        if watered:
            print("Plants were watered")
        else:
            print("No watering needed")
    
    # Clean up
    actuator_manager.cleanup()