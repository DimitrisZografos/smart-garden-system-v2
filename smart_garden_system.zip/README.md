# Smart Garden System

A simple automated plant watering system using Raspberry Pi.

Created by: Dimitris Zografos  
Date: May 2025

## Overview

This project creates an automated plant watering system that uses sensors to monitor soil moisture, temperature, humidity, and pressure. It makes intelligent watering decisions based on sensor readings and weather forecasts, and sends notifications via Telegram.

## Features

- **Soil Moisture Monitoring**: Detects when plants need water
- **Automated Watering**: Waters plants when soil moisture is low
- **Weather Integration**: Checks weather forecasts to avoid watering when rain is expected
- **Temperature & Humidity Monitoring**: Tracks environmental conditions
- **Telegram Notifications**: Sends alerts about watering events and system status
- **Image Capture**: Takes photos of plants to monitor growth
- **Data Logging**: Stores sensor readings and system events for analysis

## Hardware Requirements

- Raspberry Pi (3 or 4 recommended)
- Soil moisture sensor
- BME280 temperature/humidity/pressure sensor
- Relay module for controlling water pump
- Water pump
- Raspberry Pi Camera (optional)
- Jumper wires and breadboard

## Software Requirements

- Python 3.7+
- Required Python packages (see requirements.txt)
- Telegram bot token (for notifications)
- OpenWeatherMap API key (for weather forecasts)

## Installation

1. Clone this repository to your Raspberry Pi:
   ```
   git clone https://github.com/DimitrisZografos/smart-garden-system.git
   cd smart-garden-system
   ```

2. Install required packages:
   ```
   pip install -r requirements.txt
   ```

3. Copy the example configuration file and edit it:
   ```
   cp config/config.yaml.example config/config.yaml
   nano config/config.yaml
   ```

4. Set up your Telegram bot:
   - Create a new bot using BotFather on Telegram
   - Add the bot token to your config.yaml
   - Start a conversation with your bot
   - Get your chat ID and add it to config.yaml

5. Get an OpenWeatherMap API key:
   - Sign up at https://openweathermap.org/
   - Create an API key
   - Add the API key to your config.yaml

## Hardware Setup

### Soil Moisture Sensor
- Connect VCC to 3.3V
- Connect GND to ground
- Connect signal pin to GPIO 17 (or as configured)

### BME280 Sensor
- Connect VCC to 3.3V
- Connect GND to ground
- Connect SCL to GPIO 3 (SCL)
- Connect SDA to GPIO 2 (SDA)

### Relay Module
- Connect VCC to 5V
- Connect GND to ground
- Connect IN to GPIO 18 (or as configured)

### Water Pump
- Connect to relay module
- Ensure proper power supply for the pump

### Camera
- Connect the Raspberry Pi Camera to the camera port

## Usage

Run the main application:
```
python smart_garden.py
```

The system will:
1. Read sensor data at regular intervals
2. Check soil moisture levels
3. Water plants when needed (considering weather forecast)
4. Send notifications about system events
5. Store data for analysis

## Configuration Options

Edit `config/config.yaml` to customize:

- Sensor pins and thresholds
- Watering duration
- Check interval
- Weather location
- Notification settings

## Troubleshooting

### Sensor Readings Not Working
- Check wiring connections
- Verify GPIO pin numbers in config.yaml
- Run `python sensors.py` to test sensors independently

### Pump Not Activating
- Check relay connections
- Verify GPIO pin number in config.yaml
- Run `python actuators.py` to test pump independently

### Weather Data Not Updating
- Check your API key in config.yaml
- Verify internet connection
- Run `python weather.py` to test weather API

### Notifications Not Working
- Verify Telegram bot token and chat ID
- Ensure you've started a conversation with your bot
- Run `python notifications.py` to test notifications

## Future Improvements

- [ ] Web interface for remote monitoring and control
- [ ] Multiple zone support for different plants
- [ ] Machine learning for optimized watering schedules
- [ ] Solar power integration
- [ ] Water level monitoring for the reservoir

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- OpenWeatherMap for weather data
- Adafruit for BME280 library
- Python-Telegram-Bot for Telegram integration